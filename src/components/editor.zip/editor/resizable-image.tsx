import type React from "react"
import { NodeViewWrapper } from "@tiptap/react"
import { useState, useRef } from "react"
import { cn } from "@/core/lib/utils"

export function ResizableImageComponent({ node, updateAttributes, selected }: any) {
  const [aspectRatio, setAspectRatio] = useState(1)
  const imgRef = useRef<HTMLImageElement>(null)

  const handleLoad = () => {
    if (imgRef.current) {
      const { naturalWidth, naturalHeight } = imgRef.current
      setAspectRatio(naturalWidth / naturalHeight)

      if (!node.attrs.width && !node.attrs.height) {
        const maxWidth = 600
        const calculatedWidth = Math.min(naturalWidth, maxWidth)
        const calculatedHeight = calculatedWidth / aspectRatio

        updateAttributes({
          width: calculatedWidth,
          height: calculatedHeight,
        })
      }
    }
  }

  const handleMouseDown = (e: React.MouseEvent, direction: string) => {
    e.preventDefault()

    const startX = e.clientX
    const startY = e.clientY
    const startWidth = node.attrs.width || imgRef.current?.offsetWidth || 0
    const startHeight = node.attrs.height || imgRef.current?.offsetHeight || 0

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - startX
      const deltaY = e.clientY - startY

      let newWidth = startWidth
      let newHeight = startHeight

      if (direction.includes("right")) {
        newWidth = Math.max(50, startWidth + deltaX)
      }
      if (direction.includes("left")) {
        newWidth = Math.max(50, startWidth - deltaX)
      }
      if (direction.includes("bottom")) {
        newHeight = Math.max(50, startHeight + deltaY)
      }
      if (direction.includes("top")) {
        newHeight = Math.max(50, startHeight - deltaY)
      }

      if (direction.includes("right") || direction.includes("left")) {
        newHeight = newWidth / aspectRatio
      }

      updateAttributes({
        width: Math.round(newWidth),
        height: Math.round(newHeight),
      })
    }

    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)
  }

  return (
    <NodeViewWrapper className="relative inline-block">
      <div className={cn("relative group", selected && "ring-2 ring-blue-500 ring-offset-2")}>
        <img
          ref={imgRef}
          src={node.attrs.src || "/placeholder.svg"}
          alt={node.attrs.alt}
          width={node.attrs.width}
          height={node.attrs.height}
          onLoad={handleLoad}
          className="max-w-full h-auto rounded-md"
          draggable={false}
        />

        {selected && (
          <>
            <div
              className="absolute -top-2 -right-2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-nw-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "top-right")}
            />
            <div
              className="absolute -bottom-2 -right-2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-se-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "bottom-right")}
            />
            <div
              className="absolute -bottom-2 -left-2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-sw-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "bottom-left")}
            />
            <div
              className="absolute -top-2 -left-2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-nw-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "top-left")}
            />
            <div
              className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-n-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "top")}
            />
            <div
              className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-s-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "bottom")}
            />
            <div
              className="absolute -left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-w-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "left")}
            />
            <div
              className="absolute -right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-e-resize opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
              onMouseDown={(e) => handleMouseDown(e, "right")}
            />
          </>
        )}
      </div>
    </NodeViewWrapper>
  )
}
